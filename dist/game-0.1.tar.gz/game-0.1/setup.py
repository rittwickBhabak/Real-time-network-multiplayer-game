from setuptools import setup 
setup(name='game',
version=0.1,
description="Multiplayer game",
long_description="This is a long description",
author="Rittwick Bhabak (2022MCS2054)",
packages=["game"],
install_requires=['pymongo==4.2.0'])